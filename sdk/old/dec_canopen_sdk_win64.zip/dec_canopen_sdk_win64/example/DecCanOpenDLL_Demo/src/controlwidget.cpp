#include "controlwidget.h"
#include "ui_controlwidget.h"
#include "deccanopenapi.h"
#include <QDebug>

ControlWidget::ControlWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ControlWidget)
{
    ui->setupUi(this);
    for(int index = 1;index <= 35;++index)
        ui->cbxHM_method->addItem(QString("%1").arg(index),index);
    for(int index = -1; index >= -30;--index)
        ui->cbxHM_method->addItem(QString("%1").arg(index),index);
    on_cbxMode_currentIndexChanged(0);

    dec_initDLL(1000);
    on_txtID_editingFinished();
    this->startTimer(30);
}

ControlWidget::~ControlWidget()
{
    delete ui;
}

void ControlWidget::sendControlCmd(bool isUpdate)
{
    switch (ui->stackedWidget->currentIndex())
    {
    case 0://pp
    {
        int targetPos = ui->txtPP_pos->text().toInt();
        int vel = ui->txtPP_vel->text().toInt();
        int acc = ui->txtPP_accVel->text().toInt();
        int dec = ui->txtPP_decVel->text().toInt();
        bool isRelative = ui->cbxIsRelativePos->isChecked();
        bool isImmediately = ui->cbxIsImmediately->isChecked();
        dec_profilePositionControl(m_id,targetPos,vel,acc,dec,isRelative,isImmediately,isUpdate);
        break;
    }
    case 1://pv
    {
        int targetVel = ui->txtPV_vel->text().toInt();
        int acc = ui->txtPV_acc->text().toInt();
        int dec = ui->txtPV_dec->text().toInt();
        dec_profileVelocityControl(m_id,targetVel,acc,dec,isUpdate);
        break;
    }
    case 2://pt
    {
        int targetTorque = ui->txtPT_torque->text().toFloat();
        float slope = ui->txtPT_slope->text().toFloat();
        dec_profileTorqueControl(m_id,targetTorque,slope,isUpdate);
        break;
    }
    case 3://homing
    {
        //        HomingModePara para;
        //        para.methed = ui->cbxHM_method->currentData(Qt::UserRole).toFloat();
        //        para.searchSwitchVel = ui->txtHM_searchSwitchVel->text().toFloat();
        //        para.searchZeroVel = ui->txtHM_searchZeroVel->text().toFloat();
        //        para.accSpeed = ui->txtHM_zeroAccVel->text().toFloat();
        //        para.offset = ui->txtHM_zeroOffSet->text().toFloat();
        //        ControlManager::instance()->motorControl<HomingModePara>(para,isUpdate);
        //        break;
    }
    case 4://ip
    {
        int targetPos = ui->txtIP_pos->text().toInt();
        int vel = ui->txtIP_vel->text().toInt();
        int acc = ui->txtIP_accVel->text().toInt();
        int dec = ui->txtIP_decVel->text().toInt();
        int itpv = ui->txtIP_ipv->text().toFloat();
        bool isSync = ui->cbxIP_sync->isChecked();
        dec_interpolatePositionControl(m_id,targetPos,vel,acc,dec,itpv,isSync,isUpdate);
        break;
    }
    case 5://csp
    {
        int targetPos = ui->txtSPP_pos->text().toFloat();
        int vel = ui->txtSPP_vel->text().toFloat();
        int acc = ui->txtSPP_accVel->text().toFloat();
        int dec = ui->txtSPP_decVel->text().toFloat();
        int itpv = ui->txtSPP_ipv->text().toFloat();
        bool isSync = ui->cbxSPP_sync->isChecked();
        dec_syncPositionControl(m_id,targetPos,vel,acc,dec,itpv,isSync,isUpdate);
        break;
    }
    case 6://csv
    {
        int targetVel = ui->txtSPV_vel->text().toFloat();
        int itpv = ui->txtSPV_ipv->text().toFloat();
        int acc = ui->txtSPV_accVel->text().toFloat();
        int dec = ui->txtSPV_decVel->text().toFloat();
        bool isSync = ui->cbxSPV_sync->isChecked();
        dec_syncVelocityControl(m_id,targetVel,acc,dec,itpv,isSync,isUpdate);
        break;
    }
    case 7://cst
    {
        int targetTor = ui->txtSPT_torque->text().toFloat();
        int itpv = ui->txtSPT_itpv->text().toFloat();
        float slope = ui->txtSPT_slope->text().toFloat();
        bool isSync = ui->cbxSPT_sync->isChecked();
        dec_syncTorqueControl(m_id,targetTor,slope,itpv,isSync,isUpdate);
        break;
    }
    }
}

void ControlWidget::updateBtnState(bool state)
{
    if(state)
        ui->btnSend->setEnabled(false);
    else
        ui->btnSend->setEnabled(true);
}

void ControlWidget::on_cbxMode_currentIndexChanged(int index)
{
    ui->stackedWidget->setCurrentIndex(index);
}

void ControlWidget::on_btnSend_clicked()
{
    isStart = !isStart;
    if(isStart)
    {
        sendControlCmd(false);
        ui->btnSend->setText("停止");
    }
    else
    {
        dec_stopControl(m_id);
        ui->btnSend->setText("执行");
    }
}

void ControlWidget::on_btnUpdate_clicked()
{
    if(isStart)
        sendControlCmd(true);
}

void ControlWidget::timerEvent(QTimerEvent *event)
{
    if(-1 == m_id)
        return;
    int pos = dec_getPosition(m_id);
    int vel = dec_getVelocity(m_id);
    int cur = dec_getCurrent(m_id);
    bool enable = dec_getEnabled(m_id);
    ui->lbPos->setText(QString("%1").arg(pos));
    ui->lbVel->setText(QString("%1").arg(vel));
    ui->lbTor->setText(QString("%1").arg(cur));
    enable ? ui->lbEnable->setText("使能") : ui->lbEnable->setText("失能");
}

void ControlWidget::on_btnEnable_clicked()
{
    dec_setEnabled(m_id,true,1000);
}

void ControlWidget::on_btnDisable_clicked()
{
    dec_setEnabled(m_id,false,1000);
}

void ControlWidget::on_txtID_editingFinished()
{
    m_id = ui->txtID->text().toInt();
    if(-1 == m_id)
        return;
    ui->lbDevType->setText(QString("%1").arg(dec_getDeviceType(m_id)));
    ui->lbVendorID->setText(QString("%1").arg(dec_getVendorID(m_id)));
    ui->lbDevName->setText(QString::fromLatin1(dec_getDeviceName(m_id)));
    ui->lbProductId->setText(QString("%1").arg(dec_getProductID(m_id)));
    ui->lbSerialNum->setText(QString("%1").arg(dec_getSerialNumber(m_id)));
    ui->lbHardVer->setText(QString::fromLatin1(dec_getHardwareVersion(m_id)));
    ui->lbSoftVer->setText(QString::fromLatin1(dec_getSoftwareVersion(m_id)));
}
