#ifndef CONTROLWIDGET_H
#define CONTROLWIDGET_H

#include <QWidget>

namespace Ui {
class ControlWidget;
}

class ControlWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ControlWidget(QWidget *parent = nullptr);
    ~ControlWidget();
private:
    void sendControlCmd(bool isUpdate);
private slots:
    void updateBtnState(bool state);
private slots:
    void on_cbxMode_currentIndexChanged(int index);
    void on_btnSend_clicked();
    void on_btnUpdate_clicked();
    void on_btnEnable_clicked();
    void on_btnDisable_clicked();
    void on_txtID_editingFinished();
protected:
    virtual void timerEvent(QTimerEvent *event) override;
private:
    Ui::ControlWidget *ui;
    int m_id = -1;
    bool isStart = false;
};

#endif // CONTROLWIDGET_H
