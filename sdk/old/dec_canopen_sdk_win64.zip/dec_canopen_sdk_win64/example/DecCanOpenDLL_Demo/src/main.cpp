#include "controlwidget.h"
#include <QApplication>
#include "deccanopenapi.h"
#include <QDebug>
#include "../../CanOpenDLL/include/canopenapi.h"
#include <QTime>

void sendMsgCallFunc(const CanMsg &msg)
{
    static QTime curTime = QTime::currentTime();
    static int count = 1;
    //    if(msg.cob_id == 0x206)
    qDebug()<<count++<<"发送:"<<"cobid:"<<"0x" + QString::number(msg.cob_id,16)<<"rtr:"<<msg.rtr<<"len:"<<msg.len<<"data:"<<QByteArray((char *)msg.data,msg.len).toHex(' ')<<QTime::currentTime()<<curTime.msecsTo(QTime::currentTime());
}

void receiveMsgCallFunc(const CanMsg &msg)
{
    static QTime curTime = QTime::currentTime();
    static int count = 1;
    qDebug()<<count++<<"接收:"<<"cobid:"<<"0x" + QString::number(msg.cob_id,16)<<msg.cob_id<<"rtr:"<<msg.rtr<<"len:"<<msg.len<<"data:"<<QByteArray((char *)msg.data,msg.len).toHex(' ')<<QTime::currentTime()<<curTime.msecsTo(QTime::currentTime());
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ControlWidget w;
    w.show();
    return a.exec();
}
