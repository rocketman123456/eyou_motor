#ifndef DECCANOPENDLL_H
#define DECCANOPENDLL_H

#ifdef WIN32
#define EXTERNFUNC extern "C" __declspec(dllexport)
#else
#define EXTERNFUNC extern "C"
#endif

EXTERNFUNC int dec_getLastError();
EXTERNFUNC bool dec_initDLL(int baudrate);
EXTERNFUNC void dec_freeDLL();
EXTERNFUNC bool dec_getHeartBeat(int id, int timeOut = 100);
EXTERNFUNC bool dec_getEnabled(int id, int timeOut = 100);
EXTERNFUNC bool dec_setEnabled(int id, bool enable, int timeOut = 100);
EXTERNFUNC unsigned dec_getDeviceType(int id, int timeOut = 100);
EXTERNFUNC unsigned dec_getSyncCycle(int id, int timeOut = 100);
EXTERNFUNC bool dec_setSyncCycle(int nodeId, unsigned cycle, int timeOut = 100);
EXTERNFUNC unsigned dec_getVendorID(int id, int timeOut = 100);
EXTERNFUNC char *dec_getDeviceName(int id, int timeOut = 100);
EXTERNFUNC int dec_getProductID(int id, int timeOut = 100);
EXTERNFUNC char *dec_getHardwareVersion(int id, int timeOut = 100);
EXTERNFUNC char *dec_getSoftwareVersion(int id, int timeOut = 100);
EXTERNFUNC int dec_getSerialNumber(int id, int timeOut = 100);
//EXTERNFUNC unsigned dec_getSyncCounter(int id, int timeOut = 100);
//EXTERNFUNC bool dec_setSyncCounter(int id, unsigned count, int timeOut = 100);
EXTERNFUNC int dec_getHomeOffset(int id, int timeOut = 100);
EXTERNFUNC int dec_setHomeOffset (int id, int offSet, int timeOut = 100);
EXTERNFUNC int dec_getMaxPosition(int id, int timeOut = 100);
EXTERNFUNC bool dec_setMaxPosition(int id, int maxPos, int timeOut = 100);
EXTERNFUNC unsigned dec_getMaxVelocity(int id, int timeOut = 100);
EXTERNFUNC bool dec_setMaxVelocity(int id, unsigned maxVel, int timeOut = 100);
EXTERNFUNC int dec_getPosition(int id);
EXTERNFUNC int dec_getVelocity(int id);
EXTERNFUNC int dec_getAcceleration(int id, int timeOut = 100);
EXTERNFUNC int dec_getDeceleration(int id, int timeOut = 100);
EXTERNFUNC float dec_getCurrent(int id);
EXTERNFUNC void dec_profilePositionControl(int id, int targetPos, int vel, int acc, int dec, bool isRelative = false, bool isImmediately = false,bool isUpdate = false);
EXTERNFUNC void dec_profileVelocityControl(int id, int targetVel, int acc, int dec, bool isUpdate = false);
EXTERNFUNC void dec_profileTorqueControl(int id, int targetTorque, float slope,bool isUpdate = false);
EXTERNFUNC void dec_interpolatePositionControl(int id, int targetPos, int vel, int acc, int dec, int itpv = 20, bool isSync = false, bool isUpdate = false);
EXTERNFUNC void dec_syncPositionControl(int id, int targetPos, int vel, int acc, int dec, int itpv = 20, bool isSync = false,bool isUpdate = false);
EXTERNFUNC void dec_syncVelocityControl(int id, int targetVel, int acc, int dec, int itpv = 20, bool isSync = false, bool isUpdate = false);
EXTERNFUNC void dec_syncTorqueControl(int id, int targetTor, float slope, int itpv = 20, bool isSync = false, bool isUpdate = false);
EXTERNFUNC void dec_stopControl(int id);
#endif // DECCANOPENDLL_H
