#include <iostream>
#include <thread>
#include <csignal>
#include <iomanip>
#include "../include/eu_planet.h"

int devIndex = 0;
int channel = 0;
int id = 1;

void printCharArrayAsHex(const char *arr, size_t size)
{
    for (size_t i = 0; i < size; ++i)
    {
        std::cout << "0x" << std::hex << std::setw(2) << std::setfill('0') << (static_cast<int>(arr[i]) & 0xff);
        if (i < size - 1)
        {
            std::cout << ", ";
        }
    }
    std::cout << std::dec << " "; // 恢复十进制输出格式
}

void sendCallback(int id, const unsigned char *data, int size)
{
    std::cout << "[send]    id:" << id;
    printCharArrayAsHex((char *)data, size);
    std::cout << std::endl;
}

void receiveCallback(int id, const unsigned char *data, int size)
{
    std::cout << "[receive] id:" << id;
    printCharArrayAsHex((char *)data, size);
    std::cout << std::endl;
}

void signal_handler(int signal)
{
    planet_freeDLL(devIndex);
    exit(1);
}

// 读取电机信息示例程序
int main()
{
    signal(SIGINT, signal_handler);
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_Canable, devIndex, channel, planet_Baudrate_1000))
    {
        std::cout << "[error]test open failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    // planet_setSendCallFunction(sendCallback);
    // planet_setReceiveCallFunction(receiveCallback);
    bool heartbeat = false;
    if (PLANET_SUCCESS != planet_getHeartbeat(devIndex, id, &heartbeat))
        std::cout << "[error]get hearbeat failed!" << std::endl;
    else
        std::cout << "heart beat:" << heartbeat << std::endl;

    unsigned serialNum = 0;
    if (PLANET_SUCCESS != planet_getSerialNumber(devIndex, id, &serialNum))
        std::cout << "[error]get serial number failed!" << std::endl;
    else
        std::cout << "serial number:" << serialNum << std::endl;

    unsigned hdVersion = 0;
    if (PLANET_SUCCESS != planet_getHardwareVersion(devIndex, id, &hdVersion))
        std::cout << "[error]get hardware version failed!" << std::endl;
    else
        std::cout << "hard version:" << hdVersion << std::endl;

    unsigned fmVersion = 0;
    if (PLANET_SUCCESS != planet_getFirmwareVersion(devIndex, id, &fmVersion))
        std::cout << "[error]get firmware version failed!" << std::endl;
    else
        std::cout << "firmware version:" << fmVersion << std::endl;

    float current = 0;
    if (PLANET_SUCCESS != planet_getCurrent(devIndex, id, &current))
        std::cout << "[error]get current failed!" << std::endl;
    else
        std::cout << "current torque:" << current << std::endl;

    float velocity = 0;
    if (PLANET_SUCCESS != planet_getVelocity(devIndex, id, &velocity))
        std::cout << "[error]get velocity failed!" << std::endl;
    else
        std::cout << "current velocity:" << velocity << std::endl;

    float position = 0;
    if (PLANET_SUCCESS != planet_getPosition(devIndex, id, &position))
        std::cout << "[error]get position failed!" << std::endl;
    else
        std::cout << "current position:" << position << std::endl;

    float targetCurrent = 0;
    if (PLANET_SUCCESS != planet_getTargetCurrent(devIndex, id, &targetCurrent))
        std::cout << "[error]get target current failed!" << std::endl;
    else
        std::cout << "target current:" << targetCurrent << std::endl;

    float targetVelocity = 0;
    if (PLANET_SUCCESS != planet_getTargetVelocity(devIndex, id, &targetVelocity))
        std::cout << "[error]get target velocity failed!" << std::endl;
    else
        std::cout << "target velocity:" << targetVelocity << std::endl;

    float ratio = 0;
    if (PLANET_SUCCESS != planet_getElectronicGearRatio(devIndex, id, &ratio))
        std::cout << "[error]get electronic gear ratio failed!" << std::endl;
    else
        std::cout << "electronic gear ratio:" << ratio << std::endl;

    bool enable = false;
    if (PLANET_SUCCESS != planet_getEnabled(devIndex, id, &enable))
        std::cout << "[error]get enabled failed!" << std::endl;
    else
        std::cout << "current enable state:" << enable << std::endl;

    int mode = 0;
    if (PLANET_SUCCESS != planet_getMode(devIndex, id, &mode))
        std::cout << "[error]get mode failed!" << std::endl;
    else
        std::cout << "current mode:" << mode << std::endl;
    planet_freeDLL(devIndex);
    return 0;
}