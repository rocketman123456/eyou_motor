#include <iostream>
#include <thread>
#include <csignal>
#include <iomanip>
#include "../include/eu_planet.h"

int devIndex = 0;
int channel = 0;
int id = 1;

void printCharArrayAsHex(const char *arr, size_t size)
{
    for (size_t i = 0; i < size; ++i)
    {
        std::cout << "0x" << std::hex << std::setw(2) << std::setfill('0') << (static_cast<int>(arr[i]) & 0xff);
        if (i < size - 1)
        {
            std::cout << ", ";
        }
    }
    std::cout << std::dec << " "; // 恢复十进制输出格式
}

void sendCallback(int id, const unsigned char *data, int size)
{
    std::cout << "[send]    id:" << id;
    printCharArrayAsHex((char *)data, size);
    std::cout << std::endl;
}

void receiveCallback(int id, const unsigned char *data, int size)
{
    std::cout << "[receive] id:" << id;
    printCharArrayAsHex((char *)data, size);
    std::cout << std::endl;
}

void signal_handler(int signal)
{
    planet_freeDLL(devIndex);
    exit(1);
}

// 轮廓位置模式控制示例程序
int main()
{
    signal(SIGINT, signal_handler);
    if (PLANET_SUCCESS != planet_initDLL(planet_DeviceType_Canable, devIndex, channel, planet_Baudrate_1000))
    {
        std::cout << "[error]open failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    // planet_setSendCallFunction(sendCallback);
    // planet_setReceiveCallFunction(receiveCallback);
    bool heartbeat = false;
    if (PLANET_SUCCESS != planet_getHeartbeat(devIndex, id, &heartbeat))
    {
        std::cout << "[error]get hearbeat failed!(id not exists!)" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    //    轮廓位置模式
    if (PLANET_SUCCESS != planet_setMode(devIndex, id, 1))
    {
        std::cout << "[error]set mode failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    if (PLANET_SUCCESS != planet_setEnabled(devIndex, id, true))
    {
        std::cout << "[error]set enabled failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    if (PLANET_SUCCESS != planet_setTargetVelocity(devIndex, id, 10))
    {
        std::cout << "[error]set target velocity failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    if (PLANET_SUCCESS != planet_setTargetCurrent(devIndex, id, 2000))
    {
        std::cout << "[error]set target current failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    if (PLANET_SUCCESS != planet_setTargetAcceleration(devIndex, id, 1000))
    {
        std::cout << "[error]set target acc failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    if (PLANET_SUCCESS != planet_setTargetDeceleration(devIndex, id, 1000))
    {
        std::cout << "[error]set target dec failed!" << std::endl;
        planet_freeDLL(devIndex);
        return 0;
    }
    float pos = 180;
    while (1)
    {
        std::cout << "moving to " << pos << " degrees" << std::endl;
        if (PLANET_SUCCESS != planet_setTargetPosition(devIndex, id, pos))
        {
            std::cout << "[error]set target pos failed!" << std::endl;
            planet_freeDLL(devIndex);
            return 0;
        }
        180 == pos ? pos = 0 : pos = 180;
        std::this_thread::sleep_for(std::chrono::seconds(4));
    }
    return 0;
}